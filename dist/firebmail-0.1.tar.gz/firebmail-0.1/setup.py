from setuptools import setup, find_packages


setup(
    name='firebmail',
    version='0.1',
    license='MIT',
    author="firebreather",
    author_email='dtenny95@gmail.com',
    install_requires=[
          'python-dotenv',
      ],

)